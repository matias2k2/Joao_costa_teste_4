#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


typedef struct {
    int index;          // �ndice do documento
    double *pontos;     // Vetor de pontua��es dos assuntos
    int armario;  // Arm�rio atribu�do ao documento
} Documento;

/*	Vari�veis globais	*/
char *nomeDoFicheiro;
int numArmarios, numDoc, numAssuntos, numCelulas, i, j, k, l,m, numeroCelulasVivas=0;
/*	Cria��o de ficheiro */
FILE *ficheiro;


int verificarFicheiro();

void guardar(int numCelulas, int p1[numCelulas][numCelulas][numCelulas]);
// Fun��o para calcular a similaridade entre dois documentos
double similarity(Documento doc1, Documento doc2, int num_subjects);
int main(int argc, char *argv[]) {
	int soma;
	int mm, ii, jj, kk;
	//Ler apartir do par�metro
	printf("%s\n",argv[1]);

	//atoi � uma funcao que converte strings em numeros inteiros	
	nomeDoFicheiro = argv[1];

	
	//	Abrir o ficherio de origem 
	ficheiro = fopen(argv[1],"r");
	if(verificarFicheiro()==1){
		return;
	}
	
	fscanf(ficheiro,"%d %d %d", &numArmarios, &numDoc,&numAssuntos);
//	Documento vetDoc[numDoc];
	    Documento *documents = (Documento *) malloc(numDoc * sizeof(Documento));
	//	Leitura das coordenadas	
	for( j=0; j<numDoc; j++)
	{
		
		fscanf(ficheiro, "%d",&documents[j].index);
        documents[j].pontos = (double *) malloc(numAssuntos * sizeof(double));
		for( k=0; k<numAssuntos;k++)
		{
			fscanf(ficheiro, "%lf",&documents[j].pontos[k]);
		}	
	}
	   Documento *medArm = (Documento *) malloc(numArmarios * sizeof(Documento));
	 
	 for(i=0; i<numArmarios;i++)
		{
		medArm[i].pontos = (double *) malloc(numAssuntos * sizeof(double));
			for(k=0;k<numAssuntos;k++){
			medArm[i].pontos[k]=0;
			}
			
		}
			
	    int *armarios = (int *) malloc(numDoc * sizeof(int));
	   
			for( k=0; k<numDoc;k++)
		{
			//Distribuir os documentos no arm�rio
			armarios[k]=(k%numArmarios);
		
		}
		
		//Calcular a m�dia dos assuntos de cada arm�rio
		for(i=0; i<numArmarios;i++)
		{
			double soma=0;
				for( k=0; k<numAssuntos;k++)
					{	int cont=0;	
						for(l=0; l<numDoc; l++){
							if(armarios[l]==i){								
							medArm[i].pontos[k]=medArm[i].pontos[k]+documents[l].pontos[k];
							cont++;
						}
					}			
						if(cont!=0){
						medArm[i].pontos[k]=medArm[i].pontos[k]/cont;
					}
				}
			}
			
			//Calcular a dist�ncia de dois ponto de um documento
			double dis=0;
			double mdis=0;
			int indiceMenor=0;
			for( i=0; i<numDoc;i++)
			{
				for( k=i+1; k<numDoc;k++)
				{	
					for( l=0; l<numAssuntos;l++)
				{
						dis+=pow(documents[i].pontos[l]*documents[k].pontos[l],2);
						
				}
				//Verificar a dist�ncia menor
				if(dis<mdis)
				{
					mdis=dis;
					indiceMenor=k;
					//Adicionar no arm�rio com menor dist�ncia
					armarios[indiceMenor]=medArm[i].index;
				}
							
			}
		}
		
		FILE *fOut;
	//Abertura do ficheiro
	fOut = fopen ("output.out", "w");
	//Guardar os elementos no ficheiro
	for(m=0; m<numDoc; m++){
			fprintf(fOut,"%d %d\n", m,armarios[m]);
	}
	fclose(fOut);
			
		
	
	return 0;
}

int verificarFicheiro(){
	if(ficheiro == NULL){
		printf("Impossivel abrir o ficheiro.\n");
		return 1;
	}
	printf("Ficheiro %s aberto com sucesso.\n",nomeDoFicheiro);
	return 0;
}


